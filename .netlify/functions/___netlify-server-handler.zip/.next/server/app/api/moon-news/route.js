var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/moon-news/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__ab5688fd._.js")
R.c("server/chunks/_next-internal_server_app_api_moon-news_route_actions_012f246a.js")
R.m(5684)
module.exports=R.m(5684).exports
