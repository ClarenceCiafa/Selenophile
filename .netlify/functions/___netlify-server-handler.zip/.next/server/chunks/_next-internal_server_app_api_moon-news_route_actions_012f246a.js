module.exports=[17139,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_moon-news_route_actions_012f246a.js.map